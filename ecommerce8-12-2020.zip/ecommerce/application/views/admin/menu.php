<div id="left-sidebar" class="sidebar">
        <div class="navbar-brand">
            <a href="<?php echo base_url('admin/Home/')?>"><img src="http://www.wrraptheme.com/templates/hexabit/html/assets/images/icon-dark.svg" alt="HexaBit Logo" class="img-fluid logo"><span>E-commerce</span></a>
            <button type="button" class="btn-toggle-offcanvas btn btn-sm btn-default float-right"><i class="lnr lnr-menu fa fa-chevron-circle-left"></i></button>
        </div>
        <div class="sidebar-scroll">
            <div class="user-account">
                <div class="user_div">
                    <img src="<?php echo base_url('assets/img/profil-pic_dumm.png')?>" class="user-photo" alt="User Profile Picture">
                </div>
                <div class="dropdown">
                    <span>Welcome,</span>
                    <a href="javascript:void(0);" class="dropdown-toggle user-name" data-toggle="dropdown"><strong>E-commerce</strong></a>
                    <ul class="dropdown-menu dropdown-menu-right account">
                        <li><a href="<?php echo base_url('admin/Profile')?>"><i class="icon-user"></i>My Profile</a></li>
                        <li class="divider"></li>
                        <li><a href="<?php echo base_url('admin/Login/logout')?>"><i class="icon-power"></i>Logout</a></li>
                    </ul>
                </div>
            </div>  
            <nav id="left-sidebar-nav" class="sidebar-nav">
                <ul id="main-menu" class="metismenu">
                    <li <?php if($this->uri->segment(2)=="Home" && $this->uri->segment(3)==""){ echo "class='active'"; } ?>><a href="<?php echo base_url('admin/Home')?>"><i class="icon-home"></i><span>Dashboard</span></a></li>
                    <li <?php if($this->uri->segment(2)=="App_banner" ){ echo "class='active'"; } ?>><a href="<?php echo base_url('admin/App_banner')?>"><i class="icon-list"></i><span>App Banner</span></a></li>
                    <li <?php if($this->uri->segment(2)=="Banner" ){ echo "class='active'"; } ?>><a href="<?php echo base_url('admin/Banner')?>"><i class="icon-list"></i><span> Banner</span></a></li>
                    <li <?php if($this->uri->segment(2)=="Category" ){ echo "class='active'"; } ?>><a href="<?php echo base_url('admin/Category')?>"><i class="icon-list"></i><span>Category</span></a></li>
                    
                    <li <?php if($this->uri->segment(2)=="Brand" ){ echo "class='active'"; } ?>><a href="<?php echo base_url('admin/Brand')?>"><i class="icon-list"></i><span>Brand</span></a></li>
                    <li <?php if($this->uri->segment(2)=="Size" ){ echo "class='active'"; } ?>><a href="<?php echo base_url('admin/Size')?>"><i class="icon-list"></i><span>Size</span></a></li>
                    <li <?php if($this->uri->segment(2)=="Product" ){ echo "class='active'"; } ?>><a href="<?php echo base_url('admin/Product')?>"><i class="icon-list"></i><span>Product</span></a></li>
                   
                   <?php /* <li <?php if($this->uri->segment(2)=="News"){ echo "class='active'"; } ?>><a href="<?php echo base_url('admin/News')?>"><i class="icon-envelope"></i><span>News</span></a></li>
                      <li <?php if($this->uri->segment(2)=="Contact"){ echo "class='active'"; } ?>><a href="<?php echo base_url('admin/Contact')?>"><i class="icon-envelope"></i><span>Contact</span></a></li>
                     <li <?php if($this->uri->segment(2)=="Report"){ echo "class='active'"; } ?>><a href="<?php echo base_url('admin/Report')?>"><i class="icon-envelope"></i><span>Damage Report</span></a></li>
                        <li>
                        <a href="#Maps" class="has-arrow"><i class="icon-map"></i><span>Emergency Contact</span></a>
                        <ul>
                           <!--<li <?php if($this->uri->segment(2)=="Emergency" && $this->uri->segment(3)=="within"){ echo "class='active'"; } ?>><a href="<?php echo base_url('admin/Emergency/within')?>">Within office hr</a></li>-->
                            <li <?php if($this->uri->segment(2)=="Emergency" && $this->uri->segment(3)=="outoff"){ echo "class='active'"; } ?>><a href="<?php echo base_url('admin/Emergency/outoff')?>">Out of office hr</a></li>
                                                       
                        </ul>
                    </li>
                    <li <?php if($this->uri->segment(2)=="Magazine" ){ echo "class='active'"; } ?>><a href="<?php echo base_url('admin/Magazine')?>"><i class="icon-envelope"></i><span>Magazine</span></a></li>
                     <li <?php if($this->uri->segment(2)=="Home" && $this->uri->segment(3)=="privacy" ){ echo "class='active'"; } ?>><a href="<?php echo base_url('admin/Home/privacy')?>"><i class="icon-envelope"></i><span>Privacy</span></a></li>
                     <li <?php if($this->uri->segment(2)=="Home" && $this->uri->segment(3)=="imprint"){ echo "class='active'"; } ?>><a href="<?php echo base_url('admin/Home/imprint')?>"><i class="icon-envelope"></i><span>Imprint</span></a></li>
                     */ ?>
                    <!--<li><a href="app-chat.html"><i class="icon-bubbles"></i><span>Chat</span></a></li>-->
                    
                </ul>
            </nav>     
        </div>
    </div>