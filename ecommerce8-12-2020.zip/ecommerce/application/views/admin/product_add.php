
    <?php include('header.php');?>
    
    <?php include('menu.php');?>
    
    <style>
        .remove-icon{
            position: relative;
            left: 130px;
            font-size: 20px;
            color: red;
            bottom: 50px;

        }
        .form-group{position: relative;}
    </style>

    <div id="main-content">
        <div class="block-header">
            <div class="row clearfix">
                <div class="col-md-6 col-sm-12">
                    <h2><?php echo $page?></h2>
                </div>            
                <div class="col-md-6 col-sm-12 text-right">
                    <ul class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo base_url('admin/Home')?>"><i class="icon-home"></i></a></li>
                        <li class="breadcrumb-item">Product</li>
                        <li class="breadcrumb-item active"><?php echo $page?></li>
                    </ul>
                    
                </div>
            </div>
        </div>
        <div class="container-fluid">
            
            <div class="row clearfix">
                <div class="col-md-12">
                    <div class="card">
                        <div class="header">
                            <h2>Please fill all fields</h2>
                        </div>
                        <div class="body">
                            <form id="basic-form" method="post" action="" method="post" enctype="multipart/form-data">
                                 <div class="form-group">
                                    <label>Product Name</label>
                                    <input type="text" class="form-control" name="name" value="<?php if(!empty($records)){  echo $records->name; } ?>" required>
                                </div>
                                
                                <div class="form-group">
                                    <label>Category </label>
                                    <select name="category_id" class="form-control">
                                        <!--<option selected disabled>Select Brand</option>-->
                                        <?php foreach($records_category as $records_category){ ?>
                                        <option value="<?php echo $records_category->id;  ?>" <?php if(!empty($records)){ if($records_category->id == $records->category ) {echo "selected";} } ?>><?php echo $records_category->name; ?> </option>
                                        <?php } ?>
                                    </select>
                                </div>
                                
                                <div class="form-group">
                                    <label>Brand </label>
                                    <select name="brand_id" class="form-control">
                                        <!--<option selected disabled>Select Brand</option>-->
                                        <?php foreach($records_brand as $records_brand){ ?>
                                        <option value="<?php echo $records_brand->id;  ?>" <?php if(!empty($records)){ if($records_brand->id == $records->brand ) {echo "selected";} } ?>><?php echo $records_brand->name; ?> </option>
                                        <?php } ?>
                                    </select>
                                </div>
                                
                                 <div class="form-group">
                                    <label>Size</label>
                                    <select name="size_id[]" class="form-control" multiple <?php if(empty($records)){  echo 'required'; } ?>>
                                        
                                        <?php foreach($records_size as $records_size){
                                        $sizearr = explode(',',$records->size);
                                        ?>
                                            
                                        <option value="<?php echo $records_size->id;  ?>" <?php if(!empty($records)){ if (in_array($records_size->id, $sizearr)){echo "SELECTED";} } ?>><?php echo $records_size->name; ?> </option>
                                        <?php } ?>
                                    </select>
                                </div>
                                
                                <div class="form-group">
                                    <label>Price</label>
                                    <input type="text" class="form-control" name="price" value="<?php if(!empty($records)){  echo $records->price; } ?>" required>
                                </div>
                              
                                  <div class="form-group">
                                    <label>Image</label><br>
                                    <?php
                                   
                                    if(!empty($records)){
                                        $this->db->where('product_id',$records->id);
                                              $query=$this->db->get('product_img');
   	                                          $vw_iimg =  $query->result();
   	                                          foreach($vw_iimg as $img){
                                    ?>
                                    <a href="<?php echo base_url('admin/Product/delete_img/'.base64_encode($img->id).'/'.base64_encode($records->id)); ?>"><span class="remove-icon"><i class="fa fa-trash" aria-hidden="true"></i></span></a>
                                    <img src="<?php echo base_url($img->image)?>" class="usrpic" width="100" height="100" style="margin-left:20px;">
                                      
                                    <?php  } ?>
                                    <input type="file" class="form-control" name="image[]" multiple >
                                    <?php }else{ ?>
                                    <input type="file" class="form-control" name="image[]" multiple  required>
                                    <?php } ?>
                                    
                                </div>
                                <button type="submit" name="submit" value="save" class="btn btn-primary">Save</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            
        </div>
    </div>
    
    <?php include('footer.php');?>
