<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Product extends CI_Controller {
	
	        function __construct()
			  {
				parent::__construct();
				
				 $this->load->model('admin/Home_model');
				
				 //if($this->session->userdata["admin_user"]["type"]=='ADMIN'){}else{ redirect('admin/Home/'); }
				 
			  }


public function index()
  {
	 
	    $data["page"]="Product";
		$data["view"] = $this->Home_model->get_tbl_data(TBL_PRODUCT,array());
		$this->load->view('admin/product',$data);
 }

 /*      Add Category   */
 
public function add()
  {     
        if($this->input->post('submit')){
           
	      $size = implode(',',$this->input->post('size_id')); 
	      
			$arr = array(
			             'name'=>$this->input->post('name'),
			             'price'=>$this->input->post('price'),
			             'category'=>$this->input->post('category_id'),
			             'size'=>$size,
			             'brand'=>$this->input->post('brand_id'),
						 'created_on'=>date('Y-m-d h:i:s')
						);
			$insert = $this->Home_model->insert(TBL_PRODUCT,$arr);	
			
            if($insert){
                
              
                
				for($i=0;$i<count($_FILES['image']['name']); $i++){
				      
				        
				  if(!empty($_FILES['image']['name'][$i])){ 
				      
		              $_FILES['file']['name'] = $_FILES['image']['name'][$i];
                      $_FILES['file']['type'] = $_FILES['image']['type'][$i];
                      $_FILES['file']['tmp_name'] = $_FILES['image']['tmp_name'][$i];
                      $_FILES['file']['error'] = $_FILES['image']['error'][$i];
                      $_FILES['file']['size'] = $_FILES['image']['size'][$i];
				      
					$configs['upload_path'] = 'upload/mainproduct/';
					$configs['allowed_types'] = 'jpg|jpeg|png|gif';
					$configs['file_name'] = $_FILES['image']['name'][$i];
					
			 	    //Load upload library and initialize configuration
					$this->load->library('upload',$configs);
					$this->upload->initialize($configs);
				
					if($this->upload->do_upload('file'))
					{
					
						$uploadData = $this->upload->data();
						$image = "upload/mainproduct/".$uploadData['file_name'];
					    
					}else{
						$image = '';
						
					}
					$arrimg = array(
			             'product_id'=>$insert,
			             'image'=>$image,
						);
					
					$insertimg = $this->Home_model->insert(TBL_PRODUCT_IMG,$arrimg);	
				  }
				}
				
				$this->session->set_flashdata('message', 'Product has been added successfully');
			    redirect('admin/Product/');
			}else{
				$this->session->set_flashdata('errmessage', 'Some problem occured please try after some time');
			    redirect('admin/Product/');
			}			
			
		}
	    $data["page"]="Add Product";
	    $data["records_category"] = $this->Home_model->get_tbl_data(TBL_CATEGORY,array('status'=>1));
        $data["records_brand"] = $this->Home_model->get_tbl_data(TBL_BRAND,array('status'=>1));
	    $data["records_size"] = $this->Home_model->get_tbl_data(TBL_SIZE,array('status'=>1));

	    $this->load->view('admin/product_add',$data);
 }
 
 public function edit($cid)
  {   
      $id = base64_decode($cid);
      $rec = $this->Home_model->get_single_row(TBL_PRODUCT,array('id'=>$id));
      
        if($this->input->post('submit')){
            
             $size = implode(',',$this->input->post('size_id'));
            
           	$arr = array(
			             'name'=>$this->input->post('name'),
			             'price'=>$this->input->post('price'),
			             'category'=>$this->input->post('category_id'),
			             'size'=>$size,
			             'brand'=>$this->input->post('brand_id'),
						 'created_on'=>date('Y-m-d h:i:s')
						);
			$insert = $this->Home_model->update(TBL_PRODUCT,$id,$arr);	
            if($insert){
                
                 $c_file = count($_FILES['image']['name']);
                
                 if($c_file > 0){
                 
                	for($i=0;$i<count($_FILES['image']['name']); $i++){
				      
				        
				  if(!empty($_FILES['image']['name'][$i])){ 
				      
		              $_FILES['file']['name'] = $_FILES['image']['name'][$i];
                      $_FILES['file']['type'] = $_FILES['image']['type'][$i];
                      $_FILES['file']['tmp_name'] = $_FILES['image']['tmp_name'][$i];
                      $_FILES['file']['error'] = $_FILES['image']['error'][$i];
                      $_FILES['file']['size'] = $_FILES['image']['size'][$i];
				      
					$configs['upload_path'] = 'upload/mainproduct/';
					$configs['allowed_types'] = 'jpg|jpeg|png|gif';
					$configs['file_name'] = $_FILES['image']['name'][$i];
					
			 	    //Load upload library and initialize configuration
					$this->load->library('upload',$configs);
					$this->upload->initialize($configs);
				
					if($this->upload->do_upload('file'))
					{
					
						$uploadData = $this->upload->data();
						$image = "upload/mainproduct/".$uploadData['file_name'];
					    
					}else{
						$image = '';
						
					}
					$arrimg = array(
			             'product_id'=>$id,
			             'image'=>$image,
						);
					
					$insertimg = $this->Home_model->insert(TBL_PRODUCT_IMG,$arrimg);	
				  }
                }
                
             }
				$this->session->set_flashdata('message', 'Category has been updated successfully');
			    redirect('admin/Product/edit/'.$cid);
			}else{
				$this->session->set_flashdata('errmessage', 'Some problem occured please try after some time');
			    redirect('admin/Product/edit/'.$cid);
			}			
			
		}
	    $data["page"]="Edit Product";
	     $data["records_category"] = $this->Home_model->get_tbl_data(TBL_CATEGORY,array('status'=>1));
	    $data["records_brand"] = $this->Home_model->get_tbl_data(TBL_BRAND,array('status'=>1));
	    $data["records_size"] = $this->Home_model->get_tbl_data(TBL_SIZE,array('status'=>1));
         $data["records_img"] = $this->Home_model->get_tbl_data(TBL_PRODUCT_IMG,array('product_id'=>$id));
    	$data["records"] = $rec;
	    $this->load->view('admin/product_add',$data);
 }
 
  public function delete($id){
   /* $stores = $this->db->query("select id,category_id from stores where category_id IN($id)")->result();
    if(!empty($stores)){
        foreach($stores as $st){
            $cat[] = explode(",",$st->category_id);
        }
       array_diff( $cat, [$id] ) ;
        echo "<pre>";
        print_r($cat);
        exit;
    }
    exit; */
    //$this->Home_model->update_where(TBL_CATEGORY,array('id'=>$id),array('status'=>0));
    $this->Home_model->delete(TBL_PRODUCT,'id',$id);
    $this->Home_model->delete(TBL_PRODUCT_IMG,'product_id',$id);
	$this->session->set_flashdata('message', 'Product has been deleted successfully');
	redirect('admin/Product') ;
  
  }
  
  
  public function delete_img($id,$cid){
    
   $this->Home_model->delete(TBL_PRODUCT_IMG,'id',base64_decode($id));
	$this->session->set_flashdata('message', 'Image has been deleted successfully');
	redirect('admin/Product/edit/'.$cid) ;
  
  }
  
  
  
  
  
   
}

