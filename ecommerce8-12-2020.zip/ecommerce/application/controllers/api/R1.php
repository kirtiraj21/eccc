<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class R1 extends CI_Controller {
	  
	  function  __construct() {
        parent::__construct();
		 
		 $this->load->model('admin/Home_model','Apimodel',TRUE);
         $this->load->library('form_validation');
         
    }

public function index()
  {
      echo "Silence is Golden";
      //echo $str = mt_rand(100000000,999999999);
  }
  
public function test()
  {
     
if(!isset($_SERVER['PHP_AUTH_USER'])){
  header("www-Authenticate: basic realm=\"Private area\"");
  header("HTTP/1.0 401 Unauthorized");
  print "Sorry, You need proper credentials";
  exit;
}else{
	if(($_SERVER['PHP_AUTH_USER']=="rahul") && ($_SERVER['PHP_AUTH_PW']=="123456")){
        print "Access success";
	}else{
		header("www-Authenticate: basic realm=\"Private area\"");
		header("HTTP/1.0 401 Unauthorized");
		print "Sorry, You need proper credentials";
	}
}


}


public function phone_number(){
	 
    $this->form_validation->set_rules('phone', 'phone', 'trim|required');
   
    if($this->form_validation->run() == FALSE)
    {
        $message = strip_tags(validation_errors());
        $result = array('status'=>FALSE, 'message'=>$message, 'error'=>"");
        
    }
    else
    {
        $phone = $this->input->post('phone');
         $str = mt_rand(100000,999999);
         $otp = 6060;
      $user = $this->Apimodel->get_single_row(TBL_USER,array('phone'=>$phone));   
      $data = count($user);
      if($data == 0){
      	    $arr = array( 
      	                 "phone"=>$phone,
      	                 "otp"=>$otp,
      	                 "reff_id"=>$str,
      	                 "created_on"=>date('Y-m-d H:i:s')
      	                );
      	    
      	    $insert = $this->Apimodel->insert(TBL_USER,$arr);
      	    if($insert){
      	      // $data = $this->Apimodel->get_single_row(TBL_USER,array('id'=>$insert)); 
      	       $result = array('status'=>TRUE, 'message'=>'Number Submit successfully','data'=>$arr);
      	    }else{
      	        $result = array('status'=>FALSE, 'message'=>'Something went wrong');   
      	    }
      	    
      }else{
           $arr = array(  
                         "otp"=>$otp,
      	                 "created_on"=>date('Y-m-d H:i:s')
      	                );
      	    
      	    $insert = $this->Apimodel->update_user(TBL_USER,$phone,$arr);
          $result = array('status'=>TRUE, 'message'=>'You already registered!!');  
      }
      
    echo json_encode($result);
 }
 
} 
 

public function otp_verification(){
	 
    $this->form_validation->set_rules('otp', 'otp', 'trim|required');
    $this->form_validation->set_rules('phone', 'phone', 'trim|required');
   
    if($this->form_validation->run() == FALSE)
    {
        $message = strip_tags(validation_errors());
        $result = array('status'=>FALSE, 'message'=>$message, 'error'=>"");
        
    }
    else
    {
        $phone = $this->input->post('phone');
         $otp = $this->input->post('otp');
      $user = $this->Apimodel->get_single_row(TBL_USER,array('phone'=>$phone,'otp'=>$otp));   
      $data = count($user);
      if($data > 0){
      	 $result = array('status'=>TRUE, 'message'=>'OTP Verify successfully');
       }else{
          $result = array('status'=>FALSE, 'message'=>'Invalid OTP');  
       }
      
    echo json_encode($result);
 }
 
} 


 public function categorylist(){
     
      $user_id = $this->input->post('user_id');
       $this->form_validation->set_rules('user_id', 'user_id', 'trim|required');
        
    if($this->form_validation->run() == FALSE)
    {
        $message = strip_tags(validation_errors());
        $result = array('status'=>FALSE, 'message'=>$message, 'error'=>"");
        
    }
    else
    {
	 
	     $cat = $this->Apimodel->wheredata(TBL_CATEGORY,'status',1);     
         if(!empty($cat))
         {
             $result = array('status'=>TRUE, 'message'=>'Category list','data'=>$cat); 
         }
         else
         {
             $result = array('status'=>FALSE, 'message'=>'No Category found');  
         }
         
    }
    
      echo json_encode($result);
 }  
 
 
 
  public function banner(){
     
      $user_id = $this->input->post('user_id');
       $this->form_validation->set_rules('user_id', 'user_id', 'trim|required');
        
    if($this->form_validation->run() == FALSE)
    {
        $message = strip_tags(validation_errors());
        $result = array('status'=>FALSE, 'message'=>$message, 'error'=>"");
        
    }
    else
    {
	 
	     $banner = $this->Apimodel->selectdata(TBL_APP_BANNER);     
         if(!empty($banner))
         {
             $result = array('status'=>TRUE, 'message'=>'Banner list','data'=>$banner); 
         }
         else
         {
             $result = array('status'=>FALSE, 'message'=>'No Banner found');  
         }
         
    }
    
      echo json_encode($result);
 }  
 
 
 public function sizeslist(){
     
     $user_id = $this->input->post('user_id');
       $this->form_validation->set_rules('user_id', 'user_id', 'trim|required');
        
    if($this->form_validation->run() == FALSE)
    {
        $message = strip_tags(validation_errors());
        $result = array('status'=>FALSE, 'message'=>$message, 'error'=>"");
        
    }
    else
    {
	 
	         $size = $this->Apimodel->wheredata(TBL_SIZE,'status',1);     
          if(!empty($size))
          {
              $result = array('status'=>TRUE, 'message'=>'Size list','data'=>$size); 
          }
          else
          {
              $result = array('status'=>FALSE, 'message'=>'No Size found');  
          }
    
    }
    
      echo json_encode($result);
 }  
 
 
 
  public function brandlist(){
      
    $user_id = $this->input->post('user_id');
       $this->form_validation->set_rules('user_id', 'user_id', 'trim|required');
        
    if($this->form_validation->run() == FALSE)
    {
        $message = strip_tags(validation_errors());
        $result = array('status'=>FALSE, 'message'=>$message, 'error'=>"");
        
    }
    else
    {
	 
	       $brand = $this->Apimodel->wheredata(TBL_BRAND,'status',1);     
        if(!empty($brand))
        {
            $result = array('status'=>TRUE, 'message'=>'Brand list','data'=>$brand); 
        }
        else
        {
            $result = array('status'=>FALSE, 'message'=>'No Brand found');  
        }
    }
      echo json_encode($result);
 }  
 
 
  public function productlist(){
      
     $user_id = $this->input->post('user_id');
     $category_id = $this->input->post('category_id');
       $this->form_validation->set_rules('user_id', 'user_id', 'trim|required');
        $this->form_validation->set_rules('category_id', 'catgeory_id', 'trim|required');
    if($this->form_validation->run() == FALSE)
    {
        $message = strip_tags(validation_errors());
        $result = array('status'=>FALSE, 'message'=>$message, 'error'=>"");
        
    }
    else
    {
       $user = $this->Apimodel->get_single_row(TBL_USER,array('user_id'=>$user_id)); 
       if($user){
                  $brand_id = $this->input->post('brand_id');
                  $minprice = $this->input->post('minprice');
                  $maxprice = $this->input->post('maxprice');
                  $size_id = $this->input->post('size_id');
	 
	               if($brand_id != ''){
	                 $b_filter =$this->db->where('brand',$brand_id);
	                }else{
	                  $b_filter ="";
	                }
	                
	                if($minprice != ''){
	                 $p_filter_min =$this->db->where('price>=',(int)$minprice);
	                 $p_filter_max =$this->db->where('price<=',(int)$maxprice);
	                }else{
	                  $p_filter_min="";  
	                  $p_filter_max="";
	                }
	                    
	                $resultdata= $this->Apimodel->filterprod($category_id,$b_filter,$p_filter_min,$p_filter_max);
  	                
  	               if($resultdata){
  	                   
  	                   foreach($resultdata as $dataprod){
  	                    	$img = $this->Apimodel->wheredata(TBL_PRODUCT_IMG,'product_id',$dataprod->prod_id);     
                      
                           $dataprod->images = $img;
                           
                           $sizes = explode(',',$dataprod->prod_size); 
                           $sizearr = array();
                           foreach($sizes as $sizeprod){
                        	$sz = $this->Apimodel->wheredetail(TBL_SIZE,'id',$sizeprod);     
                            $sizearr[]=$sz;
                            //$sizeprod =$sizearr;
                           }
                            $dataprod->sizes = $sizearr ;
                            unset($sizearr);
  	                     }
  	                   
  	                   
  	                  $result = array('status'=>TRUE, 'message'=>'Product List','data'=>$dataprod); 
  	                   
  	               }else{
  	                   $result = array('status'=>FALSE, 'message'=>'No Product Found'); 
  	               }
  	                
  	               
                   
                    
        }else{
            $result = array('status'=>FALSE, 'message'=>'No User found');  
         
        }
       
    }
             echo json_encode($result);
}  
 
 
 
  
 
  
 
   public function patchlist(){
	 
    $this->form_validation->set_rules('token', 'token', 'trim|required');
    $this->form_validation->set_rules('farm_id', 'farm_id', 'trim|required');
    if($this->form_validation->run() == FALSE)
    {
        $message = strip_tags(validation_errors());
        $result = array('status'=>FALSE, 'message'=>$message, 'error'=>"");
        
    }
    else
    {
        $token = $this->input->post('token');
        $farm_id = $this->input->post('farm_id');
      	$user = $this->Apimodel->get_single_row(TBL_USER,array('token'=>$token));   
      	if($user){
      	    $farm = $this->Apimodel->get_single_row(TBL_FARM,array('id'=>$farm_id));
      	    if($farm){
      	       $patch = $this->Apimodel->get_tbl_data_col(TBL_PATCH,array('farm_id'=>$farm_id),'id,name'); 
      	       $result = array('status'=>TRUE, 'message'=>'Patch list','data'=>$patch); 
      	    }else{
      	       $result = array('status'=>FALSE, 'message'=>'No farm found');   
      	    }
      	   
      	}else{
      	    $result = array('status'=>FALSE, 'message'=>'No user found'); 
      	}
      	
        
    }
    echo json_encode($result);
 }
 
 
 
 
   public function submit(){
	 
    $this->form_validation->set_rules('token', 'token', 'trim|required');
    $this->form_validation->set_rules('task_id', 'task_id', 'trim|required');
    $this->form_validation->set_rules('farm_id', 'farm_id', 'trim|required');
    $this->form_validation->set_rules('patch_id', 'patch_id', 'trim|required');
    $this->form_validation->set_rules('size_id', 'size_id', 'trim|required');
    if($this->form_validation->run() == FALSE)
    {
        $message = strip_tags(validation_errors());
        $result = array('status'=>FALSE, 'message'=>$message, 'error'=>"");
        
    }
    else
    {
        $token = $this->input->post('token');
      	$user = $this->Apimodel->get_single_row(TBL_USER,array('token'=>$token));   
      	if($user){
      	    $arr = array( 
      	                 "token"=>$token,
      	                 "task_id"=> $this->input->post('task_id'),
      	                 "farm_id"=> $this->input->post('farm_id'),
      	                 "patch_id"=> $this->input->post('patch_id'),
      	                 "size_id"=> $this->input->post('size_id'),
      	                 "created_on"=>date('Y-m-d H:i:s')
      	                );
      	    
      	    $insert = $this->Apimodel->insert(TBL_RECORD,$arr);
      	    if($insert){
      	       $data = $this->Apimodel->get_single_row(TBL_RECORD,array('id'=>$insert)); 
      	       $data->size = $this->db->get_where(TBL_SIZE,['id'=>$data->size_id])->row()->name;
      	       $result = array('status'=>TRUE, 'message'=>'Submit successfully','data'=>$data);
      	    }else{
      	        $result = array('status'=>FALSE, 'message'=>'Something went wrong');   
      	    }
      	    
      	}else{
      	    $result = array('status'=>FALSE, 'message'=>'No user found'); 
      	}
      	
        
    }
    echo json_encode($result);
 }
 
 public function undo(){
	 
    $this->form_validation->set_rules('token', 'token', 'trim|required');
    $this->form_validation->set_rules('submit_id', 'submit_id', 'trim|required');
    if($this->form_validation->run() == FALSE)
    {
        $message = strip_tags(validation_errors());
        $result = array('status'=>FALSE, 'message'=>$message, 'error'=>"");
        
    }
    else
    {
        $token = $this->input->post('token');
        $submit_id = $this->input->post('submit_id');
      	$user = $this->Apimodel->get_single_row(TBL_USER,array('token'=>$token));   
      	if($user){
      	    $delete = $this->Apimodel->delete(TBL_RECORD,'id',$submit_id);
      	    if($delete){
      	        $result = array('status'=>TRUE, 'message'=>'Deleted successfully'); 
      	    }else{
      	        $result = array('status'=>FALSE, 'message'=>'Something went wrong');
      	    }
      	    
      	}else{
      	    $result = array('status'=>FALSE, 'message'=>'No user found'); 
      	}
      	
        
    }
    echo json_encode($result);
 }
 
  public function lastentries(){
	 
    $this->form_validation->set_rules('token', 'token', 'trim|required');
    if($this->form_validation->run() == FALSE)
    {
        $message = strip_tags(validation_errors());
        $result = array('status'=>FALSE, 'message'=>$message, 'error'=>"");
        
    }
    else
    {
        $token = $this->input->post('token');
        $user = $this->Apimodel->get_single_row(TBL_USER,array('token'=>$token));   
      	if($user){
      	    $data = $this->Apimodel->get_last_data(TBL_RECORD,array('token'=>$token),'size_id');
      	    if($data){
      	        
      	        foreach($data as $dt){
      	            $size = $this->Apimodel->get_single_row(TBL_SIZE,array('id'=>$dt->size_id)); 
      	            $dt->size = $size->name;
      	            unset($dt->size_id);
      	        }
      	        $result = array('status'=>TRUE, 'message'=>'Get successfully','data'=>$data); 
      	    }else{
      	        $result = array('status'=>FALSE, 'message'=>'Something went wrong');
      	    }
      	    
      	}else{
      	    $result = array('status'=>FALSE, 'message'=>'No user found'); 
      	}
      	
        
    }
    echo json_encode($result);
 }
 
 
  public function userlistnew(){
	 
	$users = $this->Apimodel->get_tbl_data_col(TBL_USER,array('status'=>1),'id,name,token');     
    if(!empty($users))
    {
        foreach($users as $us){
             $arr["id"] = $us->id;
             $arr["name"] = $us->name;
             $arr["token"] = $us->token;
             $task = $this->Apimodel->get_tbl_data_col('task',array(),'id,name');
             foreach($task as $tk){
                 $q["id"] = $tk->id;
                 $q["name"] = $tk->name;
                 $farms = $this->Apimodel->get_tbl_data_col('farms',array(),'id,name');
                 foreach($farms as $fm){
                     $yy["id"] = $fm->id;
                     $yy["name"] = $fm->name;
                     $yy["patches"] = $this->Apimodel->get_tbl_data_col(TBL_PATCH,array('farm_id'=>$fm->id),'id,name');
                     $ii[] = $yy;
                 }
                 $q["farms"] = $ii;
                 unset($ii);
                 $qw[] = $q;
             }
             $arr["task"] = $qw;
             unset($qw);
             $rr[] = $arr;
        }
        $sizes = $this->Apimodel->get_tbl_data_col(TBL_SIZE,array(),'id,name');
        $result = array('status'=>TRUE, 'message'=>'User list','data'=>$rr,'sizes'=>$sizes); 
    }
    else
    {
        $result = array('status'=>FALSE, 'message'=>'No user found');  
    }
    
      echo json_encode($result);
 }  
 
 

  
  
}  