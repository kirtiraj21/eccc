<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {
	
	        function __construct()
			  {
				parent::__construct();
				
				 $this->load->model('admin/Home_model');
				  $this->load->library(array('form_validation', 'email','cart','session'));
				 
			  }


public function index()
  {
      echo "Coming soon....."; exit;
        $this->load->view('index');
  }
  
  public function banner($name)
  {
        $data["view"] = $this->Home_model->get_single_row("customer",array('username'=>$name));
       // print_r(  $data["view"]);exit;
        if(empty($data["view"] )){redirect("");}
         $user_data =array(
        'username'=>$name,
        'service_id'=>0,
       );
        //ser session userdata
        $logged_in = $this->session->set_userdata('user_waxi',$user_data);
      //  echo "<pre>";print_r($_SESSION);exit;
        $this->load->view('banner',$data);
  }
  public function success()
  {
      $this->session->sess_destroy();
		$this->load->view('success');
  }
  
  public function entry()
  {
      if($this->input->post('userSubmit')){
        $user_data =array(
        'username'=>$this->input->post('username'),
        'service_id'=>$this->input->post('service_id'),
       );
        //ser session userdata
        $logged_in = $this->session->set_userdata('user_waxi',$user_data);
        redirect('Home/record');
      }
        $data["view"] = $this->Home_model->get_tbl_data("topic",array('status'=>1));
		$this->load->view('entry',$data);
  }
  
  public function record()
  {if(isset($this->session->userdata["user_waxi"]["username"])){}else{redirect("");}
      if($_FILES){
        $size = $_FILES['audio_data']['size']; //the size in bytes
$input = $_FILES['audio_data']['tmp_name']; //temporary name that PHP gave to the uploaded file
$output = $_FILES['audio_data']['name'].".wav"; //letting the client control the filename is a rather bad idea

//move the file from temp name to local folder using $output name
move_uploaded_file($input, $output)  ;
      }
		$this->load->view('record');
  }

  public function upload()
  {
     // if(isset($this->session->userdata["user_waxi"]["username"])){}else{redirect("");}
  //echo "rhul";exit;
//print_r($_FILES);exit; //this will print out the received name, temp name, type, size, etc.
if(empty($_FILES)){
    echo "0";
    die();
}

 $target_dir = "uploads/";
$target_file = $target_dir . basename($_FILES["audio_data"]["name"]);
$size = $_FILES['audio_data']['size']; //the size in bytes
$input = $_FILES['audio_data']['tmp_name']; //temporary name that PHP gave to the uploaded file
$output = $_FILES['audio_data']['name'].".wav"; //letting the client control the filename is a rather bad idea
$target_file = $target_dir . $output;
//move the file from temp name to local folder using $output name
move_uploaded_file($input, $target_file); 


echo $username = $this->session->userdata["user_waxi"]["username"];
$service_id = $this->session->userdata["user_waxi"]["service_id"];
$arr = array("username"=>$username,"service_id"=>$service_id,"audio"=>$target_file,"created_on"=>date('Y-m-d H:i:s'));
$insert = $this->Home_model->insert("feedback",$arr);
if($insert){
    echo "1";
}else{
    echo "0";
}
//echo $_FILES['audio_data']['name'];

/*if(!empty($_FILES['audio_data']['name']))
				{
					$image = $this->imagess('audio_data','uploads');
				}
				echo $image;*/
}
 public function imagess($name,$p="")
{
     if(!empty($_FILES[$name]['name']))
		{
		   
			$_FILES['file']['name'] = $_FILES[$name]['name'];
			$_FILES['file']['tmp_name'] = $_FILES[$name]['tmp_name'] ;
			$_FILES['file']['size'] = $_FILES[$name]['size'] ;
			$config['upload_path'] = 'uploads/';
			$config['allowed_types'] = 'mp3';
			$config['encrypt_name']  = TRUE;
		 	$config['file_name'] = $_FILES['file']['name'];
			
			
			$photo=explode('.',$_FILES[$name]['name']); 
			 $ext = strtolower($photo[count($photo)-1]); 
			if (!empty($_FILES[$name]['name'])) { 
			
				$curr_time = time(); 
			$filename= $this->input->post('name')."_image_".time().".".$ext; 
				} 
			 $config['file_name'] = $filename; 
			
			//Load upload library and initialize configuration
			$this->load->library('upload',$config);
			$this->upload->initialize($config);
			
				if($this->upload->do_upload('file'))
				{
					 $uploadData = $this->upload->data();
					 //echo "res1";exit;
					 $deal1image = "uploads/".$uploadData['file_name']; 
				}else{
				    echo "res2"; exit;
					return $deal1image = '';
				}
		}else{
		   // echo "res3"; exit;
		return	$deal1image = '' ;
		}	 
		
}
  public function verify($id)
  {
      $uid = base64_decode($id);
      $user = $this->Home_model->get_single_row(TBL_USER,array('id'=>$uid));
      if($user->verify==0){
        $arr =array('verify'=>1);
        $up = $this->Home_model->update(TBL_USER,'id',$arr);
        $this->session->set_flashdata('message', 'Your email has been verified succeesfully');
        redirect('Success');
      }else{
           $this->session->set_flashdata('message', 'Verification link expired');
          redirect('Expire');
      }
       
  }
}