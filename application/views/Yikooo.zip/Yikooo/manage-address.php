        
        
<?php include('header1.php'); ?>


<!-- END MAIN CONTENT -->
<div class="main_content content-bg">
    <div class="full-page-wrapper">
    <div class="container">
    <!-- START SECTION BANNER -->
     <section class="custom-design-area">
    <div class="user-area">
        <div class="row">
             <div class="col-lg-4">
                <img src="assets/img/profile-vector.png" alt="">
             </div>
             
             <div class="col-lg-8">
                    <p>Hello,</p>
                 <h5>Rizwan shah</h5>
             </div>
        </div>
    </div>
    
    <div class="sidebarmenu">
   
            <ul>
                <li>
                    <p><i class="fa fa-home" aria-hidden="true"></i>My Account <span class="float-right"><i class="fa fa-angle-right" aria-hidden="true"></i></span></p>
                    
                    <div class="inner-ul" style="display: block;">
                        <ul>
                            <li><a href="profile.php">
                              <i class="fa fa-user" aria-hidden="true"></i>  Profile Information
                            </a></li>
                            <li><a href="manage-address.php">
                            <i class="fa fa-address-card" aria-hidden="true"></i>   Manage Address
                            </a></li>
                            
                        </ul>
                    </div>
                </li>

                <li>
                    <p><i class="fa fa-sticky-note" aria-hidden="true"></i>My Orders <span class="float-right"><i class="fa fa-angle-right" aria-hidden="true"></i></span></p>

                    <div class="inner-ul" style="display: block;">
                        <ul>
                        <li><a href="order-history.php">
                            <i class="fa fa-sticky-note" aria-hidden="true"></i>
                                Order History
                            </a></li>
                        </ul>
                    </div>
                </li>

                <li>
                    <a href="wishlist.php">
                    <i class="fa fa-heart" aria-hidden="true"></i>
                        Wish List
                        <span class="float-right"></span>
                    </a>
                </li>
            
                <li>
                    <a href="notification.php">
                    <i class="fa fa-comments" aria-hidden="true"></i>
                        Notification
                        <span class="float-right"></span>
                    </a>
                </li>
                <li>
                    <a href="login.php">
                    <i class="fa fa-user-times" aria-hidden="true"></i>
                        Logout
                        <span class="float-right"></span>
                    </a>
                </li>
            </ul>
        </div>
    </section>

    <section class="page-content-wrapper">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    
                        
        <div class="profile-sec">
            <div class="container">
                <form action="">
                <div class="row" id="my-account-sec">

                <div class="col-lg-12">
                    <div class="profile-content">
                        <h4>Manage Address</h4>
                    </div>
                </div>

                <div class="col-md-12">
                        <div class="form-group mobile-align text-right">
                            <a href="address-edit.php">
                            <button type="button" class="btn btn-fill-out rounded-0"> <i class="icon-plus"></i> Add a new address</button>
                            </a>
                        </div>
                    </div>
    
                    <div class="col-md-12">
                        <div class="form-group">
                            <label for="">Address</label>
                            <input type="text" class="form-control" placeholder="Enter Address">
                        </div>
                    </div>

                    <div class="col-md-12">
                        <div class="address-view">
                            <div class="row">
                                <div class="col-lg-8 col-sm-8">
                                <p><span>Rizwan shah</span> <span><strong>1234567890</strong></span></p>
                                <p>New Palasia, A.B Road, Indore (M.P)</p>
                                </div>

                                <div class="col-lg-4 col-sm-4">
                                <div class="address-icon">
                                <a href="address-edit.php"><button class="btn btn-fill-out rounded-0"><i class="ion-edit"></i></button></a>
                                <a href="#"><button class="btn btn-fill-out rounded-0"><i class="ion-android-delete"></i></button></a>
                                </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
                </form>
            </div>
	</div>
                </div>
            </div>
        </div>
    </section>
    </div>
    </div>
    <!-- END SECTION BANNER -->
</div>
<!-- END MAIN CONTENT -->

<?php include('footer.php'); ?>




                       