        
<?php include('header.php'); ?>

<!-- START SECTION BANNER -->
<div class="breadcrumb_section bg_gray page-title-mini">
    <div class="container"><!-- STRART CONTAINER -->
        <div class="row align-items-center">
            <div class="col-md-6">
                <div class="page-title">
                    <h1>Product Categories</h1>
                </div>
            </div>
            <div class="col-md-6">
                <ol class="breadcrumb justify-content-md-end">
                    <li class="breadcrumb-item"><a href="#">Home</a></li>
                    <li class="breadcrumb-item"><a href="#">Pages</a></li>
                    <li class="breadcrumb-item active">Product Categories</li>
                </ol>
            </div>
        </div>
    </div><!-- END CONTAINER-->
</div>
<!-- END SECTION BANNER -->

<!-- END MAIN CONTENT -->
<div class="main_content">
    <!-- START SECTION BANNER -->
    <div class="section">
        <div class="container">
            <div class="row">
                <div class="col-lg-9">
                    <div class="row align-items-center mb-4 pb-1">
                        <div class="col-12">
                            <div class="product_header">
                                <div class="product_header_left">
                                    <div class="custom_select">
                                        <select class="form-control form-control-sm">
                                            <option value="order">Default sorting</option>
                                            <option value="popularity">Sort by popularity</option>
                                            <option value="date">Sort by newness</option>
                                            <option value="price">Sort by price: low to high</option>
                                            <option value="price-desc">Sort by price: high to low</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="product_header_right">
                                    <div class="products_view">
                                        <a href="javascript:Void(0);" class="shorting_icon grid"><i class="ti-view-grid"></i></a>
                                        <a href="javascript:Void(0);" class="shorting_icon list active"><i class="ti-layout-list-thumb"></i></a>
                                    </div>
                                    <div class="custom_select">
                                        <select class="form-control form-control-sm">
                                            <option value="">Showing</option>
                                            <option value="9">9</option>
                                            <option value="12">12</option>
                                            <option value="18">18</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div> 
                    <div class="row shop_container list">
                        <div class="col-md-4 col-6">
                            <div class="product">
                                <div class="product_img">
                                    <a href="product-detail.php">
                                        <img src="assets/img/product/product2.png" alt="product_img2">
                                    </a>
                                    <div class="product_action_box">
                                        <ul class="list_none pr_action_btn">
                                            <li><a href="product-detail.php"><i class="icon-magnifier-add"></i></a></li>
                                            <li><a href="wishlist.php"><i class="icon-heart"></i></a></li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="product_info">
                                    <h6 class="product_title"><a href="product-detail.php">Casual Sport Shoes</a></h6>
                                    <div class="product_price">
                                        <span class="price">$45.00</span>
                                        <del>$55.25</del>
                                        <div class="on_sale">
                                            <span>35% Off</span>
                                        </div>
                                    </div>
                                    <div class="rating_wrap">
                                        <div class="rating">
                                            <div class="product_rate" style="width:80%"></div>
                                        </div>
                                        <span class="rating_num">(21)</span>
                                    </div>
                                    <div class="pr_desc">
                                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus blandit massa enim. Nullam id varius nunc id varius nunc.</p>
                                    </div>
                                   
                                    <div class="list_product_action_box">
                                        <ul class="list_none pr_action_btn">
                                            <li class="add-to-cart"><a href="cart.php"><i class="icon-basket-loaded"></i> Add To Cart</a></li>
                                            
                                            <li><a href="product-detail.php"><i class="icon-magnifier-add"></i></a></li>
                                            <li><a href="wishlist.php"><i class="icon-heart"></i></a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4 col-6">
                            <div class="product">
                                <div class="product_img">
                                    <a href="product-detail.php">
                                        <img src="assets/img/product/product1.png" alt="product_img1">
                                    </a>
                                    <div class="product_action_box">
                                        <ul class="list_none pr_action_btn">
                                            <li><a href="product-detail.php"><i class="icon-magnifier-add"></i></a></li>
                                            <li><a href="wishlist.php"><i class="icon-heart"></i></a></li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="product_info">
                                    <h6 class="product_title"><a href="product-detail.php">Winter Grey Blazer</a></h6>
                                    <div class="product_price">
                                        <span class="price">$45.00</span>
                                        <del>$55.25</del>
                                        <div class="on_sale">
                                            <span>35% Off</span>
                                        </div>
                                    </div>
                                    <div class="rating_wrap">
                                        <div class="rating">
                                            <div class="product_rate" style="width:80%"></div>
                                        </div>
                                        <span class="rating_num">(21)</span>
                                    </div>
                                    <div class="pr_desc">
                                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus blandit massa enim. Nullam id varius nunc id varius nunc.</p>
                                    </div>
                                   
                                    <div class="list_product_action_box">
                                        <ul class="list_none pr_action_btn">
                                            <li class="add-to-cart"><a href="cart.php"><i class="icon-basket-loaded"></i> Add To Cart</a></li>
                                           
                                            <li><a href="product-detail.php"><i class="icon-magnifier-add"></i></a></li>
                                            <li><a href="wishlist.php"><i class="icon-heart"></i></a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4 col-6">
                            <div class="product">
                                <div class="product_img">
                                    <a href="product-detail.php">
                                        <img src="assets/img/product/product4.png" alt="product_img3">
                                    </a>
                                    <div class="product_action_box">
                                         <ul class="list_none pr_action_btn">
                                            <li><a href="product-detail.php"><i class="icon-magnifier-add"></i></a></li>
                                            <li><a href="wishlist.php"><i class="icon-heart"></i></a></li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="product_info">
                                    <h6 class="product_title"><a href="product-detail.php">Men's Casual Combo</a></h6>
                                    <div class="product_price">
                                        <span class="price">$45.00</span>
                                        <del>$55.25</del>
                                        <div class="on_sale">
                                            <span>35% Off</span>
                                        </div>
                                    </div>
                                    <div class="rating_wrap">
                                        <div class="rating">
                                            <div class="product_rate" style="width:80%"></div>
                                        </div>
                                        <span class="rating_num">(21)</span>
                                    </div>
                                    <div class="pr_desc">
                                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus blandit massa enim. Nullam id varius nunc id varius nunc.</p>
                                    </div>
                                    
                                    <div class="list_product_action_box">
                                        <ul class="list_none pr_action_btn">
                                            <li class="add-to-cart"><a href="cart.php"><i class="icon-basket-loaded"></i> Add To Cart</a></li>
                                           
                                            <li><a href="product-detail.php"><i class="icon-magnifier-add"></i></a></li>
                                            <li><a href="wishlist.php"><i class="icon-heart"></i></a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-12">
                            <ul class="pagination mt-3 justify-content-center pagination_style1">
                                <li class="page-item active"><a class="page-link" href="#">1</a></li>
                                <li class="page-item"><a class="page-link" href="#">2</a></li>
                                <li class="page-item"><a class="page-link" href="#">3</a></li>
                                <li class="page-item"><a class="page-link" href="#"><i class="linearicons-arrow-right"></i></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 order-lg-first mt-4 pt-2 mt-lg-0 pt-lg-0">
                    <div class="sidebar">
                        <div class="widget">
                            <h5 class="widget_title">Categories</h5>
                            <ul class="widget_categories">
                                <li>
                                <div class="custome-checkbox">
                                        <input class="form-check-input" type="checkbox" name="checkbox" id="Men" value="">
                                        <label class="form-check-label" for="Men"><span>Men</span> <span class="categories_num">(6)</span></label>
                                </div>
                                </li>
                                <li>
                                <div class="custome-checkbox">
                                        <input class="form-check-input" type="checkbox" name="checkbox" id="Boys" value="">
                                        <label class="form-check-label" for="Boys"><span>Boys</span> <span class="categories_num">(10)</span></label>
                                </div>
                                </li>
                                <li>
                                <div class="custome-checkbox">
                                        <input class="form-check-input" type="checkbox" name="checkbox" id="Formal" value="">
                                        <label class="form-check-label" for="Formal"><span>Formal</span> <span class="categories_num">(15)</span></label>
                                </div>
                                </li>
                                <li>
                                <div class="custome-checkbox">
                                        <input class="form-check-input" type="checkbox" name="checkbox" id="Casual" value="">
                                        <label class="form-check-label" for="Casual"><span>Casual</span> <span class="categories_num">(3)</span></label>
                                </div>
                                </li>
                                <li>
                                <div class="custome-checkbox">
                                        <input class="form-check-input" type="checkbox" name="checkbox" id="Funky" value="">
                                        <label class="form-check-label" for="Funky"><span>Funky</span> <span class="categories_num">(25)</span></label>
                                </div>
                                </li>
                            </ul>
                        </div>
                        <div class="widget">
                            <h5 class="widget_title">Filter</h5>
                            <div class="filter_price">
                                 <div id="price_filter" data-min="0" data-max="500" data-min-value="50" data-max-value="300" data-price-sign="$"></div>
                                 <div class="price_range">
                                     <span>Price: <span id="flt_price"></span></span>
                                     <input type="hidden" id="price_first">
                                     <input type="hidden" id="price_second">
                                 </div>
                             </div>
                        </div>
                        <div class="widget">
                            <h5 class="widget_title">Brand</h5> 
                            <ul class="list_brand">
                                <li>
                                    <div class="custome-checkbox">
                                        <input class="form-check-input" type="checkbox" name="checkbox" id="Arrivals" value="">
                                        <label class="form-check-label" for="Arrivals"><span>New Arrivals</span></label>
                                    </div>
                                </li>
                                <li>
                                    <div class="custome-checkbox">
                                        <input class="form-check-input" type="checkbox" name="checkbox" id="Lighting" value="">
                                        <label class="form-check-label" for="Lighting"><span>Fila</span></label>
                                    </div>
                                </li>
                                <li>
                                    <div class="custome-checkbox">
                                        <input class="form-check-input" type="checkbox" name="checkbox" id="Tables" value="">
                                        <label class="form-check-label" for="Tables"><span>Levis</span></label>
                                    </div>
                                </li>
                                <li>
                                    <div class="custome-checkbox">
                                        <input class="form-check-input" type="checkbox" name="checkbox" id="Chairs" value="">
                                        <label class="form-check-label" for="Chairs"><span>Spykar</span></label>
                                    </div>
                                </li>
                                <li>
                                    <div class="custome-checkbox">
                                        <input class="form-check-input" type="checkbox" name="checkbox" id="Accessories" value="">
                                        <label class="form-check-label" for="Accessories"><span>Rolex</span></label>
                                    </div>
                                </li>
                            </ul>
                        </div>
                       
                        
                       
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- END SECTION BANNER -->
</div>
<!-- END MAIN CONTENT -->

<?php include('footer.php'); ?>