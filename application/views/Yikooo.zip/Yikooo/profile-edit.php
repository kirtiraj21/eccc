        
        
<?php include('header1.php'); ?>

<!-- END MAIN CONTENT -->
<div class="main_content content-bg">
    <div class="full-page-wrapper">
    <div class="container">
    <!-- START SECTION BANNER -->
<section class="custom-design-area">
    <div class="user-area">
        <div class="row">
             <div class="col-lg-4">
                <img src="assets/img/profile-vector.png" alt="">
             </div>
             
             <div class="col-lg-8">
                    <p>Hello,</p>
                 <h5>Rizwan shah</h5>
             </div>
        </div>
    </div>
    
    <div class="sidebarmenu">
   
            <ul>
                <li>
                    <p><i class="fa fa-home" aria-hidden="true"></i>My Account <span class="float-right"><i class="fa fa-angle-right" aria-hidden="true"></i></span></p>
                    
                    <div class="inner-ul" style="display: block;">
                        <ul>
                            <li><a href="profile.php">
                              <i class="fa fa-user" aria-hidden="true"></i>  Profile Information
                            </a></li>
                            <li><a href="manage-address.php">
                            <i class="fa fa-address-card" aria-hidden="true"></i>   Manage Address
                            </a></li>
                            
                        </ul>
                    </div>
                </li>

                <li>
                    <p><i class="fa fa-sticky-note" aria-hidden="true"></i>My Orders <span class="float-right"><i class="fa fa-angle-right" aria-hidden="true"></i></span></p>

                    <div class="inner-ul" style="display: block;">
                        <ul>
                        <li><a href="order-history.php">
                            <i class="fa fa-sticky-note" aria-hidden="true"></i>
                                Order History
                            </a></li>
                        </ul>
                    </div>
                </li>

                <li>
                    <a href="wishlist.php">
                    <i class="fa fa-heart" aria-hidden="true"></i>
                        Wish List
                        <span class="float-right"></span>
                    </a>
                </li>
            
                <li>
                    <a href="notification.php">
                    <i class="fa fa-comments" aria-hidden="true"></i>
                        Notification
                        <span class="float-right"></span>
                    </a>
                </li>
                <li>
                    <a href="login.php">
                    <i class="fa fa-user-times" aria-hidden="true"></i>
                        Logout
                        <span class="float-right"></span>
                    </a>
                </li>
            </ul>
        </div>
    </section>

    <section class="page-content-wrapper">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    
                        
        <div class="profile-sec">
            <div class="container">
                <form action="">
                <div class="row" id="my-account-sec">

                <div class="col-lg-12">
                    <div class="profile-content">
                        <h4>Personal Information</h4>
                    </div>
                </div>

                    <div class="col-md-12">
                        <div class="profile-img mt-profile edit-img">
						<!-- User Profile Image -->
						<img class="profile-pic" src="https://bodyfuel.ng/bodyfuel_partnership/assets/front/images/dummyprofile.png" alt="">
						<!-- Default Image -->
						<!-- <i class="fa fa-user fa-5x"></i> -->
					</div>
					<div class="p-image"> <i class="fa fa-camera upload-button"></i>
						<input class="file-upload" type="file" name="image" accept="image/*">
					</div>
                    </div>
    
                    <div class="col-md-12">
    
                       <div class="row">
						<div class="col-lg-6 col-md-6">
                            <div class="form-group">
                                <label for="">First Name</label>
                                <input type="text" class="form-control" placeholder="Enter First Name">
                            </div>
                        </div>
                        
                        <div class="col-lg-6 col-md-6">
                            <div class="form-group">
                                <label for="">Last Name</label>
                                <input type="text" class="form-control" placeholder="Enter Last Name">
                            </div>
						</div>
                           <div class="col-lg-6 col-md-6">
                           <div class="form-group">
                                <label for="">Email</label>
                                <input type="email" class="form-control" placeholder="Enter Email Address">
                            </div>
                           </div>
    
                           <div class="col-lg-6 col-md-6">
                           <div class="form-group">
                                <label for="">Contact</label>
                                <input type="number" class="form-control" placeholder="Enter Contact Number">
                            </div>
                           </div>

                        <div class="col-lg-12 col-md-6">
                            <div class="edit-profile">
                            <a href="shop.php" class="btn btn-fill-out rounded-0">Submit</a>
                            </div>
                        </div>

                       </div>
                    </div>
                </div>
                </form>
            </div>
	</div>
                </div>
            </div>
        </div>
    </section>
    </div>
    </div>
    <!-- END SECTION BANNER -->
</div>
<!-- END MAIN CONTENT -->

<?php include('footer.php'); ?>

<script>
$(document).ready(function() {
var readURL = function(input) {
if (input.files && input.files[0]) {
var reader = new FileReader();

reader.onload = function (e) {
$('.profile-pic').attr('src', e.target.result);
}

reader.readAsDataURL(input.files[0]);
}
}


$(".file-upload").on('change', function(){
readURL(this);
});

$(".upload-button").on('click', function() {
$(".file-upload").click();
});
});
</script>




