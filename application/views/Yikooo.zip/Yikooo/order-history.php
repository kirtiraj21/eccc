
<?php include('header1.php'); ?>


<!-- END MAIN CONTENT -->
<div class="main_content content-bg">
    <div class="full-page-wrapper">
    <div class="container">
    <!-- START SECTION BANNER -->
   <section class="custom-design-area">
    <div class="user-area">
        <div class="row">
             <div class="col-lg-4">
                <img src="assets/img/profile-vector.png" alt="">
             </div>
             
             <div class="col-lg-8">
                    <p>Hello,</p>
                 <h5>Rizwan shah</h5>
             </div>
        </div>
    </div>
    
    <div class="sidebarmenu">
   
            <ul>
                <li>
                    <p><i class="fa fa-home" aria-hidden="true"></i>My Account <span class="float-right"><i class="fa fa-angle-right" aria-hidden="true"></i></span></p>
                    
                    <div class="inner-ul" style="display: block;">
                        <ul>
                            <li><a href="profile.php">
                              <i class="fa fa-user" aria-hidden="true"></i>  Profile Information
                            </a></li>
                            <li><a href="manage-address.php">
                            <i class="fa fa-address-card" aria-hidden="true"></i>   Manage Address
                            </a></li>
                            
                        </ul>
                    </div>
                </li>

                <li>
                    <p><i class="fa fa-sticky-note" aria-hidden="true"></i>My Orders <span class="float-right"><i class="fa fa-angle-right" aria-hidden="true"></i></span></p>

                    <div class="inner-ul" style="display: block;">
                        <ul>
                        <li><a href="order-history.php">
                            <i class="fa fa-sticky-note" aria-hidden="true"></i>
                                Order History
                            </a></li>
                        </ul>
                    </div>
                </li>

                <li>
                    <a href="wishlist.php">
                    <i class="fa fa-heart" aria-hidden="true"></i>
                        Wish List
                        <span class="float-right"></span>
                    </a>
                </li>
            
                <li>
                    <a href="notification.php">
                    <i class="fa fa-comments" aria-hidden="true"></i>
                        Notification
                        <span class="float-right"></span>
                    </a>
                </li>
                <li>
                    <a href="login.php">
                    <i class="fa fa-user-times" aria-hidden="true"></i>
                        Logout
                        <span class="float-right"></span>
                    </a>
                </li>
            </ul>
        </div>
    </section>

    <section class="page-content-wrapper">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    
                        
        <div class="profile-sec">
            <div class="container">
                <form action="">
                <div class="row" id="my-account-sec">

                <div class="col-lg-12">
                    <div class="profile-content">
                        <h4>My Orders</h4>
                    </div>
                </div>


                    <!-- order history start here -->

                    <!-- 1st item history -->

                <div class="col-lg-12">
                   <div class="card card-order">
                   <div class="row">
                    <div class="col-lg-3">
                        <a href="product-detail.php">
                        <img src="assets/img/product/product2.png" alt="product_img3">
                        </a>
                    </div>

                    <div class="col-lg-9">
                    <div class="product_info">
                        <h6 class="product_title">
                            <a href="product-detail.php">Men Sport Shoes</a>
                        </h6>
                        <p>Casual trending sport shoes exclusive available for men </p>
                       
                        <div class="product_price">
                            <span class="price">$55.00</span>
                            <del>$15.00</del>
                            <div class="on_sale">
                                <span>25% Off</span>
                            </div>
                        </div>

                        <div class="product-wishlist">
                        <div class="rating_wrap">
                        
                       <div class="rating-area">
                           <button class="ratingbtn">
                             4.5 <i class="linearicons-star"></i> 
                           </button>
                       </div>
                       
                        <div class="product-stock">
                        <span>In Stock</span>
                        <span class="rating_num">(10)</span>
                        </div>

                        </div>
                        </div>

                        
                        <!-- <ul class="progressbar">
                            <li>
                            <span><i class="fas fa-check"></i></span>
                            </li>
                            <li>
                            <span><i class="fas fa-check"></i></span>
                            </li>
                        </ul> -->

                        <ul class="progressbar">
                                <li class="active">Ordered</li>
                                <li>Shipped</li>
                        </ul>
                       

                        </div>
                    </div>

                    <!-- <div class="col-lg-4">
                        <div class="product_info">
                        <span class="price">Offers : </span>
                        <span class="on_sale">1</span>
                        <p>
                        <a href="#">
                        <button class="cancel-btn"> X Cancel</button>
                        </a>
                        </p>
                        </div>
                    </div> -->

                    <div class="col-lg-12">
                    <div class="card-header">

                    <div class="row">
                    <div class="col-lg-6 col-md-6">
                    <div class="text-left">
                    <span>Ordered On <strong>Wed, May 24th 2020</strong></span>
                    </div>
                    </div>

                    <div class="col-lg-6 col-md-6">
                   <div class="text-right">
                   <span>Order Total <strong>$55.00</strong></span>
                   </div>
                    </div>
                    </div>

                    </div>
                    </div>


                    </div>
                   </div>
                </div>

                    <!-- 2nd item history -->

                    <div class="col-lg-12 mt-3">
                   <div class="card card-order">
                   <div class="row">
                    <div class="col-lg-3">
                        <a href="product-detail.php">
                        <img src="assets/img/product/product4.png" alt="product_img3">
                        </a>
                    </div>

                    <div class="col-lg-9">
                    <div class="product_info">
                        <h6 class="product_title">
                            <a href="product-detail.php">Men Casual Outfit Combo</a>
                        </h6>
                        <p>Casual trending outfit exclusively available for men </p>
                       
                        <div class="product_price">
                            <span class="price">$170.00</span>
                            <del>$45.00</del>
                            <div class="on_sale">
                                <span>35% Off</span>
                            </div>
                        </div>

                        <div class="product-wishlist">
                        <div class="rating_wrap">
                        
                       <div class="rating-area">
                           <button class="ratingbtn">
                             3.5 <i class="linearicons-star"></i> 
                           </button>
                       </div>
                       
                        <div class="product-stock outstock">
                        <span>Out of Stock</span>
                        <span class="rating_num">(0)</span>
                        </div>

                        </div>
                        </div>
                        
                        <ul class="progressbar">
                                <li class="active">Ordered</li>
                                <li>Shipped</li>
                        </ul>
                        </div>
                    </div>

                    <!-- <div class="col-lg-4">
                        <div class="product_info">
                        <span class="price">Offers : </span>
                        <span class="on_sale">2</span>
                        <p>
                        <a href="#">
                        <button class="cancel-btn"> X Cancel</button>
                        </a>
                        </p>
                        </div>
                    </div> -->

                    <div class="col-lg-12">
                    <div class="card-header">

                    <div class="row">
                    <div class="col-lg-6 col-md-6">
                    <div class="text-left">
                    <span>Ordered On <strong>Wed, Aug 24th 2020</strong></span>
                    </div>
                    </div>

                    <div class="col-lg-6 col-md-6">
                   <div class="text-right">
                   <span>Order Total <strong>$170.00</strong></span>
                   </div>
                    </div>
                    </div>

                    </div>
                    </div>


                    </div>
                   </div>
                </div>

                <!-- item history end here -->

                </div>
                </form>
                </div>
	            </div>
                </div>
            </div>
        </div>
    </section>
    </div>
    </div>
    <!-- END SECTION BANNER -->
</div>
<!-- END MAIN CONTENT -->

<?php include('footer.php'); ?>




